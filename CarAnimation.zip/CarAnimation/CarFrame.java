import javax.swing.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/*
   Programmer: Param A Ri
   Class: CSCI-1301
   Date: 4/25/14
   Instructor: Mrs. Jackson
**/

public class CarFrame extends JFrame
{
   private MovingCar animation;
   
   class KeyStrokeListener implements KeyListener
   {
      public void keyPressed(KeyEvent event) 
      {
         String key = KeyStroke.getKeyStrokeForEvent(event).toString().replace("pressed ", ""); 
         if (key.equals("LEFT"))
         {
            animation.moveCarBy(-4,0);
         }
         else if (key.equals("RIGHT"))
         {
            animation.moveCarBy(4,0);
         }
      }
      public void keyTyped(KeyEvent event) {}
      public void keyReleased(KeyEvent event) {}
   }

   
   public CarFrame()
   {
      animation = new MovingCar();
      add(animation);
      
      setSize(1200,400);
      
      animation.addKeyListener(new KeyStrokeListener());
      animation.setFocusable(true);

   }
}